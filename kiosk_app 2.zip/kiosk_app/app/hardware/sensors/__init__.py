"""Hardware sensor modules"""

# Sensor modules would be imported here when implemented
# from .thermometer import Thermometer
# from .blood_pressure import BloodPressureMonitor

__all__ = [
    # Will be populated when sensor modules are implemented
]